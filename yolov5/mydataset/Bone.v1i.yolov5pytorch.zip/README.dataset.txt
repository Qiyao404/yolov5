# Bone > 2023-12-07 12:03pm
https://universe.roboflow.com/kwan-buradinsahim-ytiqu/bone-ic6ct

Provided by a Roboflow user
License: CC BY 4.0

